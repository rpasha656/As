var envConfig = require('./utils/env');
var vendorNpmFiles = require('./vendor-npm.config');
var fontFiles = require('./fonts.config')
var argv = require('yargs').argv;
module.exports = function () {
    var root = '',
        nodeRoot = 'node_modules/',
        src = root + 'src/',
        config = root + 'config/',
        app = src + 'app/',
        test = src + 'test/',
        tmp = 'dist/',
        tmpApp = tmp + 'app/',
        tmpTest = tmp + 'test/',
        testHelper = test + 'test-helpers/',
        e2e = root + 'e2e/',
        assets = 'assets/',
        assetsPath = {
            styles: assets + 'styles/',
            images: assets + 'images/',
            fonts: assets + 'fonts/'
        },
        tsFiles = [
            src + '**/!(*.spec)+(.ts)'
        ],
        tsTestFiles = {
            unit: [app + '**/*.spec.ts'],
            e2e: [e2e + '**/*.ts'],
            helper: [testHelper + '**/*.ts']
        },
        report = {
            path: 'report/'
        };

    var e2eConfig = {
        seleniumTarget: 'http://127.0.0.1:3000'
    };

    var systemJs = {
        configFileName: 'system-config.js',
        builder: {
            minify: true,
            mangle: true,
            runtime: false,
            globalDefs: {
                DEBUG: false,
                ENV: 'production'
            }
        }
    };

    var gulpConfig = {
        root: root,
        nodeRoot: nodeRoot,
        config: config,
        src: src,
        app: app,
        test: test,
        tmp: tmp,
        tmpApp: tmpApp,
        tmpTest: tmpTest,
        testHelper: testHelper,
        e2e: e2e,
        e2eConfig: e2eConfig,
        assets: assets,
        index: null,
        report: report,
        assetsPath: assetsPath,
        tsFiles: tsFiles,
        tsTestFiles: tsTestFiles,
        systemJs: systemJs,
        vendorNpmFiles: vendorNpmFiles,
        fontFiles: fontFiles
    };

    if (envConfig.ENV === envConfig.ENVS.DEV) {
        var historyApiFallback = require('connect-history-api-fallback');
        var compress = require('compression');
        var browserSync = {
            dev: {
                port: argv.port || 3000,
                server: {
                    baseDir: './dist/',
                    middleware: [historyApiFallback(), compress()]
                },
                https: {
                    key: "config/cert/server.key",
                    cert: "config/cert/server.crt"
                },
                cors: true
            },
            prod: {
                port: argv.port || 3001,
                server: {
                    baseDir: './dist/',
                    middleware: [historyApiFallback(), compress()]
                },
                https: {
                    key: "config/cert/server.key",
                    cert: "config/cert/server.crt"
                },
                cors: true
            }
        };

        gulpConfig.browserSync = browserSync;
    }

    return gulpConfig;
};
