﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class FileMetadataService {
    constructor(private http: Http) { }
    addFileMetaData(filemetadata: Object) {
        let filemetadataString = JSON.stringify(filemetadata); // Stringify payload
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON        
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.post('https://localhost:44391/api/files', filemetadataString, options) // ...using post request
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data            
    }
    getCategories() {
        return this.http.get('https://localhost:44391/api/Categories') // ...using post request
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data
    }
    getFileMetadatalisting(id: string) {
        return this.http.get('https://localhost:44391/api/plans/planbyid?id=' + id) // ...using post request
            .map((res: Response) => res.json());
    }
    getFileMetadataById(id: number) {
        return this.http.get('https://localhost:44391/api/files/' + id) // ...using post request
            .map((res: Response) => res.json());
    }
    getFileMetadataByFilters(id: number, numberofdays: number) {
        return this.http.get('https://localhost:44391/api/files/' + id + '/' + numberofdays) // ...using post request
            .map((res: Response) => res.json());
    }
    addCategory(category: any) {
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.post('https://localhost:44391/api/Categories', category, options) // ...using post request
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data
    }
    updateCategory(categoryId: number, category: any) {
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.post('https://localhost:44391/api/Categories/' + categoryId, category, options) // ...using post request
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data
    }
    addSubCategory(categoryId: number, subcategory: any) {
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.post('https://localhost:44391/api/Categories/' + categoryId + '/subcategories', subcategory, options)
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data
    }
    updateSubCategory(categoryId: number, subcategoryId: number, subcategory: any) {
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.post
            ('https://localhost:44391/api/Categories/' + categoryId + '/subcategories/' + subcategoryId, subcategory, options)
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data
    }
}
