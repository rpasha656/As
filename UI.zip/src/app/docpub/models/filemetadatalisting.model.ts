export class FileMetadataListing {
    id: number;
    name: string;
    description: string = '';
    createdby: string = '';
    isactive: boolean = true;
    editable: boolean;
    showSubcategory: boolean;
    subCategories: SubCategories[];
    constructor(subCategories: SubCategories[]) { this.subCategories = []; }
}
export class SubCategories {
    id: number;
    name: string;
    description: string = '';
    createdby: string = '';
    isactive: boolean = true;
    editable: boolean;
    showSubcategory: boolean;
    fileMetadata: FileMetadataModel[];
    constructor(fileMetadata: FileMetadataModel[]) { this.fileMetadata = []; }
}
export class FileMetadataByPlans {
    planName: string;
    fileMetadatalist: FileMetadataModel[];
    constructor(fileMetadatalist: FileMetadataModel[]) { this.fileMetadatalist = []; }
}
export class FileMetadataModel {
    id: number;
    accessedOn: Date;
    categoryId: number;
    subCategoryId: number;
    expirationDate: Date;
    fileExtensionId: number;
    fileName: string;
    planName: string;
    statusDate: Date;
    sposId: number;
    statusId: number;
    isActive: boolean;
}
