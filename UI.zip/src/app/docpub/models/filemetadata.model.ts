export class FileMetadata {
    public accessedOn: Date;
    public categoryId: number;
    public subCategoryId: number;
    public expirationDate: string;
    public file: any;
    public fileExtensionId: number;
    public fileName: string;
    public displayName: string;
    public planName: string;
    public statusDate: Date;
    public sposId: string;
    public statusId: number;
    public isActive: boolean;
    public fileStream: any;
    public fileSize: number;
    public id: number;
    public sposUrl: string;

    static clone(filemetadata: FileMetadata): FileMetadata {
        return new FileMetadata(filemetadata.accessedOn,
            filemetadata.categoryId,
            filemetadata.subCategoryId,
            filemetadata.expirationDate,
            filemetadata.fileExtensionId,
            filemetadata.file,
            filemetadata.fileName,
            filemetadata.displayName,
            filemetadata.planName,
            filemetadata.statusDate,
            filemetadata.sposId,
            filemetadata.statusId,
            filemetadata.isActive,
            filemetadata.fileStream,
            filemetadata.fileSize,
            filemetadata.id,
            filemetadata.sposUrl);
    }

    constructor(accessedOn: Date,
        categoryId: number,
        subCategoryId: number,
        expirationDate: string,
        fileExtensionId: number,
        file: any,
        fileName: string,
        displayName: string,
        planName: string,
        statusDate: Date,
        sposId: string,
        statusId: number,
        isActive: boolean,
        fileStream: any,
        fileSize: number,
        id: number,
        sposUrl: string) {
        this.accessedOn = accessedOn;
        this.categoryId = categoryId;
        this.subCategoryId = subCategoryId;
        this.expirationDate = expirationDate;
        this.fileExtensionId = fileExtensionId;
        this.file = file;
        this.fileName = fileName;
        this.displayName = displayName;
        this.planName = planName;
        this.statusDate = statusDate;
        this.sposId = sposId;
        this.statusId = statusId;
        this.isActive = isActive;
        this.fileStream = fileStream;
        this.fileSize = fileSize;
        this.id = id;
        this.sposUrl = sposUrl;
    }

    clear() {
        this.accessedOn = new Date();
        this.categoryId = 0;
        this.subCategoryId = 0;
        this.fileExtensionId = 1;
        this.file = '';
        this.fileName = '';
        this.displayName = ' ';
        this.planName = '';
        this.statusDate = new Date();
        this.sposId = '2';
        this.statusId = 0;
        this.isActive = true;
        this.fileStream = '';
        this.fileSize = 0;
        this.id = 0;
        this.sposUrl = '';
    }
}
