import { Component, Inject } from '@angular/core';
import { Title, PubSubServiceContract } from 'microui-contracts';
import { ActivatedRoute } from '@angular/router';
import { FileMetadataService } from './index';
@Component({
    moduleId: module.id,
    selector: 'as-docpub',
    template: require('./docpub.component.html')
})
export class DocpubComponent {
    public selectedPlanName: string;
    public showNoRowsMessage: Boolean;
    public showfilelisting: Boolean;
    public fileMetadataListing: any;
    public countries: any = [];
    data = [
        { 'key': 1, 'name': 'INDIA' },
        { 'key': 2, 'name': 'USA' },
        { 'key': 3, 'name': 'AUSTRALIA' },
        { 'key': 4, 'name': 'ENGLAND' },
    ];
    public arrayOfStrings: any = [];
    constructor(private pubsub: PubSubServiceContract, @Inject(Title) public title: string,
        private filemetadataService: FileMetadataService, private route: ActivatedRoute) {
        this.route.params.subscribe((params: { planname: string }) => this.selectedPlanName = params.planname);
        if (this.selectedPlanName === undefined || this.selectedPlanName === 'undefined') {
            this.selectedPlanName = 'Select';
        }
        else {
            this.getFileMetadatalisting(this.selectedPlanName);
        }
        this.countries = this.data;
        console.log(this.data);
        this.arrayOfStrings = [{ id: 1, value: 'One' }, { id: 2, value: 'Two' }, { id: 3, value: 'Three' }, { id: 4, value: 'Four' }];
    }
    getFileMetadatalisting(planname: string) {
        this.showNoRowsMessage = false;
        this.filemetadataService.getFileMetadatalisting(planname).subscribe(res => this.populateFileListing(res.categories, true),
            err => this.populateFileListing(err, false));
    };
    populateFileListing(fileListingData: any, isSuccess: boolean) {
        this.fileMetadataListing = fileListingData;
        this.showfilelisting = isSuccess ? true : false;
        this.showNoRowsMessage = !this.showfilelisting;
        console.log(this.showNoRowsMessage);
    };
}
