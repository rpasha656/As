import { NgForm } from '@angular/forms';
declare var $: any;
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FileMetadataService, FileMetadataListing, FileMetadata, SubCategories, FileExtension } from './index';
@Component({
    selector: 'as-upload',
    template: require('./upload.component.html'),
    styles: [`
    input.ng-dirty.ng-invalid { border: solid red 2px; }
    select.ng-dirty.ng-invalid { border: solid red 2px; }
  `]

})

export class UploadComponent {
    public showErrorMsg: boolean;
    public fileMetadata: FileMetadata;
    public subcategory: SubCategories[];
    public subJsonData: Object[];
    public category: FileMetadataListing[];
    public fileUploadSuccess: number;
    public counterValue: number;
    public date: Date = new Date();
    public expDate: string;
    public isDisableIncrement: Boolean;
    public isDisableDecrement: Boolean;
    public wrongExtension: boolean;
    public fileExtension: String;
    public successmessage: boolean;
    public selectedPlan: string;
    public currentMonthDate: string;
    public showDelete: Boolean;
    public file: any;
    constructor(private filemetadataService: FileMetadataService, private route: ActivatedRoute) {
        this.successmessage = false;
        this.fileMetadata = new FileMetadata
            (new Date(), 0, 0, new Date().toDateString(), FileExtension.txt, ' ', ' ', ' ', 'HUM', new Date(), '2', 1, true, '', 0, 0, '');
        this.subcategory = [];
        this.category = [new FileMetadataListing(this.subcategory)];
        this.filemetadataService.getCategories().subscribe(res => this.category = res);
        this.fileUploadSuccess = 0;
        this.fileMetadata.displayName = '';
        this.fileMetadata.file = '';
        this.fileMetadata.expirationDate = '';
        this.date = new Date();
        this.counterValue = this.date.getFullYear() + 1;
        this.currentMonthDate = this.date.getMonth() + 1 + '/' + this.date.getDate();
        this.expDate = this.currentMonthDate + '/' + this.counterValue;
        this.fileMetadata.expirationDate = this.expDate;
        this.isDisableIncrement = true;
        this.isDisableDecrement = false;
        this.file = '';
        this.wrongExtension = false;
        this.fileExtension = '';
        this.showDelete = false;
        this.route.params.subscribe((params: { planname: string }) => this.selectedPlan = params.planname);
        this.route.params.subscribe((params: { id: number }) => {
            if (params.id) {
                this.getFileMetadataById(params.id);
            }
        });
    }
    bindCategories(res: any) {
        this.fileMetadata = res;
        let updatedate = new Date(this.fileMetadata.expirationDate);
        this.fileMetadata.expirationDate = updatedate.getMonth() + 1 + '/' + updatedate.getDate() + '/' + updatedate.getFullYear();
        this.counterValue = updatedate.getFullYear();
        if (this.fileMetadata.categoryId !== 0) {
            for (let x = 0; x < this.category.length; x++) {
                if (this.category[x].id === this.fileMetadata.categoryId) {
                    this.subJsonData = this.category[x].subCategories;
                }
            }
        }
    }
    increment(form: NgForm) {
        this.counterValue++;
        this.fileMetadata.expirationDate = this.currentMonthDate + '/' + this.counterValue;
        this.isDisableDecrement = false;
        this.isDisableIncrement = false;
        if (this.counterValue === (this.date.getFullYear() + 8)) {
            this.isDisableIncrement = false;
            this.isDisableDecrement = true;
            return;
        }
    }
    decrement(form: NgForm) {
        this.counterValue--;
        this.fileMetadata.expirationDate = this.currentMonthDate + '/' + this.counterValue;
        this.isDisableDecrement = false;
        this.isDisableIncrement = false;
        if (this.counterValue === (this.date.getFullYear() + 1)) {
            this.isDisableIncrement = true;
            this.isDisableDecrement = false;
            return;
        }
    }
    changeSubCate(selectedCategory) {
        for (let x = 0; x < this.category.length; x++) {
            if (this.category[x].id === Number(selectedCategory.target.value)) {
                this.subJsonData = this.category[x].subCategories;
            }
        }
    }
    fileChanged($event, form: NgForm) {
        this.file = (<HTMLInputElement>document.querySelector('input[type=file]')).files[0];
        this.fileMetadata.fileName = $event.srcElement.files[0].name;
        this.fileMetadata.file = $event.srcElement.files;
        this.fileMetadata.fileSize = this.file.size;
        let fileExtension = this.file.name.split('.').pop();
        this.fileExtension = fileExtension;
        if (fileExtension === 'txt' || fileExtension === 'pdf' || fileExtension === 'xlsx' ||
            fileExtension === 'xls' || fileExtension === 'docx' || fileExtension === 'doc' ||
            fileExtension === 'csv' || fileExtension === 'ppt' ||
            fileExtension === 'pptx' || fileExtension === 'rtf' || fileExtension === 'tif' ||
            fileExtension === 'zip' || fileExtension === 'tiff') {
            this.wrongExtension = false;
            console.log(this.wrongExtension);
        } else { this.wrongExtension = true; }
    }

    checkLength(name) {
        if (name.target.value && (name.target.value.toString().length >= 40)) {
            this.showErrorMsg = true;
            name.target.value = name.target.value.substring(0, 40);
        } else {
            this.showErrorMsg = false;
        }
    }
    onSubmit(form: NgForm, status: string) {
        let fileMetadata = FileMetadata.clone(this.fileMetadata);
        fileMetadata.fileExtensionId = FileExtension[this.fileExtension.toString()];
        if (status === 'delete') {
            fileMetadata.statusId = (fileMetadata.statusId === 3 ? 6 : 5);
            fileMetadata.isActive = false;
        }
        else {
            fileMetadata.fileName = this.fileMetadata.file;
        }
        this.fileMetadata.expirationDate = this.expDate;
        this.fileExtension = '';
        this.wrongExtension = false;
        this.showErrorMsg = false;
        this.filemetadataService.addFileMetaData(fileMetadata).subscribe(res => this.addSuccessfull(res, form));
    };
    addSuccessfull(createdFileMetadataId: number, form: NgForm) {
        if (createdFileMetadataId > 0) {
            this.fileMetadata.clear();
            this.fileUploadSuccess = createdFileMetadataId;
        }
        if (createdFileMetadataId < 0) { this.fileUploadSuccess = -1; }
        this.successmessage = true;
    }
    getFileMetadataById(id: number) {
        this.filemetadataService.getFileMetadataById(id).subscribe(res => this.bindCategories(res));
        this.showDelete = true;
    }
    confirmdelete() {
        $('#deleteModal').modal();
    }
}
