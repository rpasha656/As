import { Component, Input } from '@angular/core';
import { FileMetadataService } from './index';
@Component({
    selector: 'as-filelisting',
    template: require('./file-listing.component.html')
})

export class FileListingComponent {
    @Input() filemetadatalisting;
    @Input() showNoRowsMessage: boolean;
    @Input() showfilelisting: Boolean;
    public sorting: any;
    public columns: any[];
    public classCollapse: string;
    public parentClassCollapse: string;
    public expandAllCollapseAllButton: string;
    public subCategoryCount: number;
    constructor(private filemetadataService: FileMetadataService) {
        this.classCollapse = 'accordian-body collapse';
        this.parentClassCollapse = 'accordion-toggle collapsed';
        this.expandAllCollapseAllButton = 'fa fa-chevron-down';
        this.subCategoryCount = 0;
        this.columns = [
            {
                display: 'Document', // The text to display
                variable: 'displayName', // The name of the key that's apart of the data array                
                typehref: true,
                htmltext: '',
                width: '22%'

            },
            {
                display: 'Filename', // The text to display
                variable: 'fileName', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '20%'
            },
            {
                display: 'Size', // The text to display
                variable: 'FileSize', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '5%'
            },
            {
                display: 'Status', // The text to display
                variable: 'statusName', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '8%'
            },
            {
                display: 'Status Date', // The text to display
                variable: 'statusDate', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '9%'
            },
            {
                display: 'Downloaded', // The text to display
                variable: 'LastDownLoaded', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '10%'
            },
            {
                display: 'Expires', // The text to display
                variable: 'expirationDate', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '8%'
            },
            {
                display: 'Published By', // The text to display
                variable: 'UserId', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '11%'
            },
            {
                display: '', // The text to display
                variable: '', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: `Test`,
                width: '8%'
            }
        ];
        this.sorting = {
            column: 'fileName', // to match the variable of one of the columns
            descending: false
        };
    }
    expandAll(changeClass: string) {
        console.log(changeClass);
        if (changeClass === 'accordion-toggle') {
            this.classCollapse = 'accordian-body collapse';
            this.parentClassCollapse = 'accordion-toggle collapsed';
            this.expandAllCollapseAllButton = 'fa fa-chevron-down';
        }
        else {
            this.classCollapse = 'accordian-body collapse in';
            this.parentClassCollapse = 'accordion-toggle';
            this.expandAllCollapseAllButton = 'fa fa-chevron-up';
        }
    }
    setSubCategoryCount(fileCount: number, count: number) {
        if (fileCount !== 0) {
            this.subCategoryCount = count + 1;
            return false;
        }
        else {
            return true;
        }
    }
    clearSubCategoryCount() {
        this.subCategoryCount = 0;
    }
    showOrHideCategory(searchString, categoryCount: number) {
        if (searchString !== '' && categoryCount === 0) {
            return true;
        }
        else {
            return false;
        }
    }
}
