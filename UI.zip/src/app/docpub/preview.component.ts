import { Component, Input } from '@angular/core';
@Component({
    selector: 'as-preview',
    template: require('./preview.component.html'),

})

export class PreviewComponent {

    public showErrorMsg: boolean;
    public previewMsg: String;
    public showPreview: Boolean;
    public wrongExtension: boolean;
    public fileExtension: String;
    public pdfSrc: string;
    public page: number;
    public rotation: number;
    public zoom: number;
    public originalSize: boolean;
    public showAll: boolean;
    public pdf: any;
    public renderText: boolean;

    constructor() {
        this.showPreview = true;
        this.wrongExtension = false;
        this.fileExtension = '';
        this.pdfSrc = '';
        this.page = 1;
        this.rotation = 0;
        this.zoom = 1.5;
        this.originalSize = true;
        this.showAll = true;
        this.pdf = '';
        this.renderText = true;
        this.afterLoadComplete = this.afterLoadComplete.bind(this);
    }
    @Input()
    set filePath(_filePath: any) {
        let file = _filePath;
        let reader = new FileReader();
        let self = this;
        let extension = '';
        if (file.name !== undefined && file.name !== '') {
            extension = file.name.split('.').pop();
            this.fileExtension = extension;
            console.log(this.fileExtension);
        }

        if (extension === 'txt' || extension === 'pdf' || extension === 'xlsx' ||
            extension === 'xls' || extension === 'docx' || extension === 'doc' || extension === 'csv' || extension === 'ppt' ||
            extension === 'pptx' || extension === 'rtf' || extension === 'tif' || extension === 'zip' || extension === 'tiff') {
            this.wrongExtension = false;
            reader.onload = (e: any) => {
                this.pdfSrc = e.target.result;
            };
            reader.addEventListener('load', function () {
                self.showPreview = false;
                if (extension === 'txt' || extension === 'csv' || extension === 'rtf') {
                    if (extension === 'txt' || extension === 'rtf') {
                        self.previewMsg = reader.result;
                    } else {
                        self.createTable(reader.result);
                    }
                } else if (extension === 'tif' || extension === 'tiff') {
                    let element: HTMLImageElement;
                    element = <HTMLImageElement>document.getElementById('imageUpload');
                    element.src = reader.result;
                } else {
                    self.previewMsg = 'The preview of this file type is not supported by the browser';
                }
            }, false);
            if (file) {
                if (extension === 'tif' || extension === 'tiff') {
                    reader.readAsDataURL(file);
                } else if (extension === 'pdf') {
                    reader.readAsArrayBuffer(file);
                } else {
                    reader.readAsText(file);
                }
            }
        } else { this.wrongExtension = true; }
    }
    createTable(data) {
        let tabletag = '<table>';
        let arr = data.split(/[\n\r]/g);
        for (let i = 0; i < arr.length; i++) {
            let col = arr[i].split(',');
            if (i === 0) {
                tabletag = tabletag + '<tr>';
                for (let j = 0; j < col.length; j++) {
                    tabletag += '<th>';
                    tabletag += col[j];
                    tabletag += '</th>';
                }
                tabletag += '</tr>';
            } else {
                tabletag = tabletag + '<tr>';
                for (let j = 0; j < col.length; j++) {
                    tabletag += '<td>';
                    tabletag += col[j];
                    tabletag += '</td>';
                }
                tabletag += '</tr>';
            }
        }
        tabletag += '</table>';
        document.getElementById('csvTable').innerHTML = tabletag;
    }
    afterLoadComplete(pdf: any) {
        this.pdf = pdf;
    }

}
