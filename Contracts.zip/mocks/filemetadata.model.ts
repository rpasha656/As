export class FileMetadata {
    constructor(
        public accessedOn: Date,
        public categoryId: number,
        public subCategoryId: number,
        public expirationDate: Date,
        public fileExtensionId: number,
        public fileName: string,
        public planName: string,
        public publicationDate: Date,
        public sposId: number,
        public statusId: number
    ) { }
}